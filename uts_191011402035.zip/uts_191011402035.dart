import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YANA YULIA DEWI',
      home: Scaffold(
        appBar: AppBar(
          title: Text('YANA YULIA DEWI'),
          centerTitle: true,
        ),
        body: GridView.count(
          primary: false,
          padding: const EdgeInsets.all(20),
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          crossAxisCount: 3,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('one'),
              ),
              color: Colors.teal[100],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('two'),
              ),
              color: Colors.teal[200],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('three'),
              ),
              color: Colors.teal[300],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('four'),
              ),
              color: Colors.teal[400],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('five'),
              ),
              color: Colors.teal[500],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('six'),
              ),
              color: Colors.teal[600],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('seven'),
              ),
              color: Colors.teal[700],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('eight'),
              ),
              color: Colors.teal[800],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('nine'),
              ),
              color: Colors.teal[900],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('ten'),
              ),
              color: Colors.green[100],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('eleven'),
              ),
              color: Colors.green[200],
            ),
            Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: const Text('twelve'),
              ),
              color: Colors.green[300],
            ),
          ],
        ),
      ),
    );
  }
}